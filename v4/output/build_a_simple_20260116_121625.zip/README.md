# build_a_simple

build a simple essay workflow where the enduser inputs their essay and the code returns a rating and review of that essay.

## Installation

\`\`\`bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
\`\`\`

## Usage

```bash
python main.py
```
