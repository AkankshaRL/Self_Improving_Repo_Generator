"""
This module contains prompt templates used in the LangGraph workflow.
"""

from typing import Dict, Any

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableSequence


# Prompt for assigning a topic to the user.
ASSIGN_TOPIC_PROMPT: ChatPromptTemplate = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            "You are an AI assistant that assigns a topic to a user for an essay. "
            "Choose a topic that is interesting and allows for a good essay. "
            "Keep the topic concise and clear.",
        ),
        ("human", "Assign a topic for an essay."),
    ]
)

# Prompt for evaluating the user's essay.
EVALUATE_ESSAY_PROMPT: ChatPromptTemplate = ChatPromptTemplate.from_messages(
    [
        (
            "system",
            """You are an AI essay grader. Your task is to evaluate an essay based on the following criteria:
1. Relevance: How well does the essay address the assigned topic?
2. Mistakes: How many factual or logical errors are present in the essay?
3. Grammar: How well is the essay written in terms of grammar, spelling, and punctuation?

Provide a score from 1 to 5 for each criterion, where 1 is poor and 5 is excellent.
Also, provide a brief explanation for each score.
Format your output as a JSON object with the following keys: "relevance", "mistakes", "grammar", and "explanation".
The "explanation" key should contain a string detailing your reasoning for the scores.
""",
        ),
        (
            "human",
            "Essay Topic: {topic}\n\nEssay:\n{essay}\n\nEvaluate the essay.",
        ),
    ]
)


def create_evaluate_essay_chain() -> RunnableSequence[Dict[str, str], Dict[str, Any]]:
    """
    Creates a LangChain expression language (LCEL) chain for evaluating an essay.

    Returns:
        A RunnableSequence that takes a dictionary with 'topic' and 'essay' keys
        and returns a dictionary containing the evaluation results.
    """
    return EVALUATE_ESSAY_PROMPT | RunnableSequence.from_batch(
        lambda x: x
    )  # Placeholder for potential future processing or model integration