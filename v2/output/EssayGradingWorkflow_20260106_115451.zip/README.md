# Essay Grading Workflow

This project implements a basic essay grading workflow using LangGraph and Google's Gemini-2.5-Flash LLM.

## Features

*   **Topic Generation**: Assigns a random essay topic to the user.
*   **Essay Input**: Allows the user to input their essay.
*   **Automated Grading**: Rates the essay on relevance, factual/logical mistakes, and grammar/style.
*   **Comprehensive Feedback**: Provides an overall feedback summary with specific areas for improvement.

## Prerequisites

*   Python 3.8+
*   A Google Cloud account with the Gemini API enabled.

## Installation

1.  **Clone the repository:**
    bash
    git clone <repository_url>
    cd EssayGradingWorkflow
    

2.  **Create a virtual environment (recommended):**
    bash
    python -m venv venv
    source venv/bin/activate  # On Windows use `venv\Scripts\activate`
    

3.  **Install dependencies:**
    bash
    pip install -r requirements.txt
    
    *(Note: `requirements.txt` is not explicitly generated in this JSON, but you would typically create one from the `dependencies` list.)*

## Environment Variables

Set your Google API key as an environment variable:

bash
export GOOGLE_API_KEY='YOUR_GOOGLE_API_KEY'


Replace `YOUR_GOOGLE_API_KEY` with your actual API key.

## Usage

Run the main script:

bash
python main.py


The script will:
1.  Print a generated essay topic.
2.  Prompt you to enter your essay.
3.  Process the essay using the Gemini LLM.
4.  Output the relevance score, mistakes score, grammar score, and overall feedback.

## Project Structure

*   `main.py`: The main entry point orchestrating the LangGraph workflow.
*   `state.py`: Defines the state structure for the workflow.
*   `prompts.py` (placeholder): Intended for prompt templates, though inlined in `main.py` for simplicity.

## Testing

Basic tests can be performed by running `main.py` and providing different essay inputs. For automated testing, you would typically use a testing framework like `pytest` and mock LLM responses or use specific test inputs.
