import os
import json
from typing import Annotated, Dict, List, Literal, Optional, TypedDict

from dotenv import load_dotenv
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.graph import StateGraph, END
from pydantic import BaseModel, Field

# Load environment variables from .env file
load_dotenv()

# --- Configuration ---
# Ensure you have your GOOGLE_API_KEY set in your .env file
# or as an environment variable.
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise ValueError("GOOGLE_API_KEY not found. Please set it in your .env file or environment variables.")

# --- Pydantic Models ---
class GradingResult(BaseModel):
    """Represents the structured grading result from the LLM."""
    relevance_score: int = Field(..., ge=1, le=5)
    relevance_feedback: str
    mistakes_found: List[str] = Field(default_factory=list)
    mistakes_feedback: str
    grammar_score: int = Field(..., ge=1, le=5)
    grammar_feedback: str
    overall_feedback: str

class WorkflowState(TypedDict):
    """Represents the state of the workflow."""
    topic: Optional[str]
    essay: Optional[str]
    grading_result: Optional[GradingResult]
    assign_topic_attempt: Annotated[int, "Number of times topic assignment has been attempted"]


# --- Model Initialization ---
# Initialize the Gemini-2.5-Flash model
llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", google_api_key=GOOGLE_API_KEY)

# --- Prompt Templates ---
# Prompt for assigning a topic
topic_assignment_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", "You are an AI assistant that assigns interesting and diverse topics for essays."),
        ("human", "Please suggest a topic for an essay. The topic should be suitable for a general audience and encourage critical thinking."),
    ]
)

# Prompt for essay input and grading
essay_grading_prompt = ChatPromptTemplate.from_messages(
    [
        ("system", """You are an AI essay grader. You will be given an essay and a topic.
        Your task is to grade the essay based on the following criteria:
        1. Relevance to the topic: How well does the essay address the assigned topic?
        2. Mistakes: Identify any factual errors, logical fallacies, or significant omissions.
        3. Grammar and Style: Assess the clarity, coherence, and correctness of the language.

        Provide your feedback in a structured JSON format with the following keys:
        - "relevance_score": A score from 1 to 5 (1 being poor, 5 being excellent).
        - "relevance_feedback": A brief explanation of the relevance score.
        - "mistakes_found": A list of identified mistakes. If no mistakes are found, this should be an empty list.
        - "mistakes_feedback": A brief explanation of the mistakes found.
        - "grammar_score": A score from 1 to 5 (1 being poor, 5 being excellent).
        - "grammar_feedback": A brief explanation of the grammar score.
        - "overall_feedback": A concise overall summary of the essay's strengths and weaknesses.
        """),
        ("human", "Topic: {topic}\n\nEssay:\n{essay}"),
    ]
)

# --- Graph Nodes ---

def assign_topic_node(state: WorkflowState) -> Dict:
    """
    Assigns a topic to the user.

    Args:
        state: The current state of the workflow.

    Returns:
        A dictionary containing the assigned topic.
    """
    print("\n--- Assigning Topic ---")
    if state.get("assign_topic_attempt", 0) > 2:
        print("Too many attempts to assign a topic. Ending workflow.")
        return {"topic": None}  # Indicate failure to assign topic

    chain = topic_assignment_prompt | llm | StrOutputParser()
    topic = chain.invoke({})
    print(f"Assigned Topic: {topic}")
    return {"topic": topic, "assign_topic_attempt": state.get("assign_topic_attempt", 0) + 1}


def get_essay_node(state: WorkflowState) -> Dict:
    """
    Prompts the user to input their essay.

    Args:
        state: The current state of the workflow.

    Returns:
        A dictionary containing the user's essay.
    """
    print("\n--- Essay Input ---")
    topic = state.get("topic")
    if not topic:
        print("No topic assigned. Cannot proceed with essay input.")
        return {"essay": None}

    essay = input(f"Please write your essay on the topic: '{topic}'\n")
    print("Essay received.")
    return {"essay": essay}


def grade_essay_node(state: WorkflowState) -> Dict:
    """
    Grades the user's essay based on the assigned topic.

    Args:
        state: The current state of the workflow.

    Returns:
        A dictionary containing the grading results.
    """
    print("\n--- Grading Essay ---")
    topic = state.get("topic")
    essay = state.get("essay")

    if not topic or not essay:
        print("Missing topic or essay. Cannot grade.")
        return {"grading_result": None}

    chain = essay_grading_prompt | llm | StrOutputParser()
    try:
        grading_output = chain.invoke({"topic": topic, "essay": essay})
        print(f"Raw Grading Output:\n{grading_output}")

        try:
            # Attempt to parse the output using Pydantic model for validation
            grading_result_data = json.loads(grading_output)
            grading_result = GradingResult(**grading_result_data)
            print("Essay graded successfully.")
            return {"grading_result": grading_result}
        except json.JSONDecodeError:
            print("Failed to parse grading output as JSON. Returning raw output with error.")
            return {"grading_result": GradingResult(
                relevance_score=1,
                relevance_feedback="JSON parsing failed",
                mistakes_found=[],
                mistakes_feedback="The LLM did not return valid JSON.",
                grammar_score=1,
                grammar_feedback="The LLM did not return valid JSON.",
                overall_feedback="Error: Could not parse grading output."
            )}
        except Exception as pydantic_error:
            print(f"Pydantic validation error: {pydantic_error}. Returning raw output with error.")
            return {"grading_result": GradingResult(
                relevance_score=1,
                relevance_feedback="Pydantic validation failed",
                mistakes_found=[],
                mistakes_feedback=f"Pydantic validation failed: {pydantic_error}",
                grammar_score=1,
                grammar_feedback="Pydantic validation failed",
                overall_feedback="Error: Could not validate grading output."
            )}

    except Exception as e:
        print(f"An error occurred during grading: {e}")
        return {"grading_result": GradingResult(
            relevance_score=1,
            relevance_feedback="LLM execution error",
            mistakes_found=[],
            mistakes_feedback=f"An error occurred during LLM execution: {e}",
            grammar_score=1,
            grammar_feedback="LLM execution error",
            overall_feedback="Error: An unexpected error occurred during grading."
        )}


def decide_on_topic_assignment(state: WorkflowState) -> Literal["assign_topic", "continue_to_essay", "end_workflow"]:
    """
    Decision node to determine if topic assignment needs to be retried or if we can proceed.

    Args:
        state: The current state of the workflow.

    Returns:
        The next node to execute.
    """
    if state.get("topic") is None and state.get("assign_topic_attempt", 0) <= 2:
        return "assign_topic"
    elif state.get("topic") is None:
        return "end_workflow"  # Stop if topic assignment failed after multiple attempts
    else:
        return "continue_to_essay"


def decide_on_essay_input(state: WorkflowState) -> Literal["get_essay", "grade_essay"]:
    """
    Decision node to determine if essay input is needed or if we can proceed to grading.

    Args:
        state: The current state of the workflow.

    Returns:
        The next node to execute.
    """
    if state.get("essay") is None:
        return "get_essay"
    else:
        return "grade_essay"


# --- Graph Compilation ---

def create_workflow_graph():
    """
    Creates and compiles the LangGraph workflow.

    Returns:
        The compiled LangGraph graph.
    """
    builder = StateGraph(WorkflowState)

    # Add nodes
    builder.add_node("assign_topic", assign_topic_node)
    builder.add_node("get_essay", get_essay_node)
    builder.add_node("grade_essay", grade_essay_node)

    # Add edges
    # Initial entry point: start by assigning a topic
    builder.set_entry_point("assign_topic")

    # Conditional branching for topic assignment
    builder.add_conditional_edges(
        "assign_topic",
        decide_on_topic_assignment,
        {
            "assign_topic": "assign_topic",  # Retry topic assignment
            "continue_to_essay": "get_essay",  # Proceed to get essay
            "end_workflow": END # End if topic assignment fails
        },
    )

    # Conditional branching for essay input
    builder.add_conditional_edges(
        "get_essay",
        decide_on_essay_input,
        {
            "get_essay": "get_essay",  # Retry essay input (though this is usually manual)
            "grade_essay": "grade_essay",  # Proceed to grade essay
        },
    )

    # Direct edge from grading to end
    builder.add_edge("grade_essay", END)

    # Compile the graph
    graph = builder.compile()
    return graph


# --- Main Execution ---
if __name__ == "__main__":
    workflow = create_workflow_graph()

    # Initial state for the workflow
    initial_state: WorkflowState = {"topic": None, "essay": None, "grading_result": None, "assign_topic_attempt": 0}

    print("Starting LangGraph Essay Grading Workflow...")

    # Run the workflow
    for step in workflow.stream(initial_state, {"recursion_limit": 10}):
        for key, value in step.items():
            print(f"Node: {key}")
            # Print state updates for clarity, but avoid printing large data structures repeatedly
            if key == "assign_topic":
                print(f"  Topic assigned: {value.get('topic')}")
            elif key == "get_essay":
                print(f"  Essay input received.")
            elif key == "grade_essay":
                print(f"  Grading result received.")
                # Optionally print a summary of the grading result
                if value.get("grading_result"):
                    result = value["grading_result"]
                    if result.relevance_score == 1 and "error" in result.relevance_feedback: # Check for error indicators
                        print(f"  Error during grading: {result.overall_feedback}")
                    else:
                        print(f"  Relevance Score: {result.relevance_score}")
                        print(f"  Grammar Score: {result.grammar_score}")
                        print(f"  Overall Feedback: {result.overall_feedback}")

    print("\nWorkflow finished.")