from typing import Optional, Dict

from pydantic import BaseModel, Field, ConfigDict


class State(BaseModel):
    """
    Represents the state of the essay grading workflow.

    Attributes:
        topic (Optional[str]): The assigned topic for the essay.
        essay (Optional[str]): The user's submitted essay.
        scores (Optional[Dict[str, float]]): A dictionary containing the scores
            for relevance, mistakes, and grammar.
        feedback (Optional[Dict[str, str]]): A dictionary containing feedback
            for relevance, mistakes, and grammar.
    """

    topic: Optional[str] = Field(default=None, description="The assigned topic for the essay.")
    essay: Optional[str] = Field(default=None, description="The user's submitted essay.")
    scores: Optional[Dict[str, float]] = Field(
        default_factory=dict,
        description="A dictionary containing the scores for relevance, mistakes, and grammar.",
    )
    feedback: Optional[Dict[str, str]] = Field(
        default_factory=dict,
        description="A dictionary containing feedback for relevance, mistakes, and grammar.",
    )

    model_config = ConfigDict(
        arbitrary_types_allowed=True,  # Allow arbitrary types if needed, though not strictly necessary here
        extra="allow",  # Allow extra fields not defined in the model
    )